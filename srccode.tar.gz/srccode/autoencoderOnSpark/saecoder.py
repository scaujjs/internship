


from pyspark import SparkConf,SparkContext
import copy, numpy as np
import random
import time

DNS="spark://ip-172-31-94-77.ec2.internal:7077"
arg0=10
arg1=5




iteration=arg1
number=int(np.power(arg0,0.5))


conf=SparkConf().setMaster(DNS).setAppName("SAEcoder")
##conf=SparkConf().setMaster("spark://ip-172-31-84-91.ec2.internal:7077").setAppName("SAEcoder")
##conf=SparkConf().setMaster("spack:ec2-174-129-130-94.compute-1.amazonaws.com:7077").setAppName("SAEcoder")
sc=SparkContext(conf=conf)

def sigmoid(x):
    return 1/(1+np.exp(-x))

def sigmoid_otput_to_derivation(output):
    return output*(1-output)


'''
    def calculateDelta(output,target):
       assert len(output)==len(target)
       result=list()
       for i in range(len(output)):
           result.append((output[i][0],target[i][1]-output[i][0]))

        return result

'''

class Sautoecoder():
    def __init__(self,node,alpha,randomSize):
        self.randomSize=randomSize
        self.node=node
        self.alpha=alpha
        self.W=list()
        self.W_R=list()
        self.B=list()
        self.B_R=list()
        self.V=list()
        self.D=list()

    ## result or input should be sorted by key
    ## this can be rewrited by paralise, may promote the eff


    def pretrain(self,iteration,inputSet,alpha):
        for i in range(len(self.node)-2):
            print("pretraining"+str(i))
            inputSet=self.pretrainForlayerX(iteration,inputSet,i,alpha)


    def pretrainForlayerX(self,iteration,X,layer,alpha):
        self.W.append(list())
        self.B.append(list())
        self.W_R.append(list())
        self.B_R.append(list())

        newSet=list()

        for i in range(self.node[layer]):
            self.B_R[layer].append((i,0.0))
            for j in range(self.node[layer+1]):
                self.W[layer].append(((i,j),2*self.randomSize *random.random()-self.randomSize))


        for i in range(self.node[layer+1]):
            self.B[layer].append((i,0.0))
            for j in range(self.node[layer]):
                self.W_R[layer].append(((i, j), 2 * self.randomSize * random.random() - self.randomSize))

        for i in range(iteration):

            for j in range(len(X)):

                (value,delta,output)=self.ffForPre(X[j],layer)
                self.bpForPre(value,delta,layer,X[j],alpha)
                print("output: "+str(output))
                if (i==iteration-1):
                    newSet.append(output)


        return newSet

        ##
        ##after this we can clear the W_R to save the space

        ##input is the set, key is the dimension(INT), value is the value
    def ffForPre(self,input,layer):

        weight=self.W[layer]
        nodeNum=self.node[layer+1]
        B=self.B[layer]
        ##B1=self.B_R[layer]



##this place can be faster???
        def multiply((key,value)):
            result=list()
            for i in range(nodeNum):
                result.append(((key,i),value))

            return result

        def sigmoidinner((key,value)):
            v=sigmoid(value[0]+value[1])
            return(key,v)

        bRDD=sc.parallelize(B)
        inputRDD=sc.parallelize(input)
        weightRDD=sc.parallelize(weight)

        multiValueRDD=inputRDD.flatMap(multiply)
        value=multiValueRDD.join(weightRDD).map(lambda (key,value):(key[1],value[0]*value[1])).reduceByKey(lambda x,y: x+y).join(bRDD).map(sigmoidinner).collect()

        weight=self.W_R[layer]
        nodeNum=self.node[layer]
        B=self.B_R[layer]
        bRDD=sc.parallelize(B)
        valueinputRDD=sc.parallelize(value)##.map(lambda value:(value[0],value[1]))  ##(dim,value)->(from,to),value)
        weightRDD=sc.parallelize(weight)##.map(lambda value:(value[0],value[1]))
        multiValueRDD=valueinputRDD.flatMap(multiply)


        output=multiValueRDD.join(weightRDD).map(lambda (key,value):(key[1],value[0]*value[1])).reduceByKey(lambda x,y: x+y).join(bRDD).map(sigmoidinner).collect()

        ##print("value: " + str(output))

        def calculateDelta((key,value)):
            delta=(value[0] - value[1])*(value[1] * (1 - value[1]))

            return(key,delta)

        inputRDD=sc.parallelize(input)
        outputRDD=sc.parallelize(output)
        delta=inputRDD.join(outputRDD).map(calculateDelta).collect()
   ##     print("delta For T"+str(delta))
        return (value, delta,output)




    def bpForPre(self,value,delta,layer,input,alpha):

        weight=self.W_R[layer]
        nodeNum=self.node[layer+1]


        def multiply((key,delta)):
            result=list()
            for i in range(nodeNum):
                result.append(((key,i),delta))

            return result

        delta_O_RDD = sc.parallelize(delta)
        w_H_T_RDD=sc.parallelize(weight)##.map(lambda value:(value[0],value[1]))  ##(dim,value)->(from,to),value)
        output_H_RDD=sc.parallelize(value)
        multi_Delta_O_RDD=delta_O_RDD.flatMap(multiply).map(lambda (x,y):((x[1],x[0]),y)).persist()
        delta_H=multi_Delta_O_RDD.join(w_H_T_RDD).map(lambda (key,value):(key[0],value[0]*value[1])).reduceByKey(lambda x,y: x+y).join(output_H_RDD).map(lambda (key,value):(key,value[0]*value[1]*(1-value[1]))).collect()

      ##  print("before update B:"+str(self.B[layer]))
     ##   print("before update BR:"+str(self.B_R[layer]))

        B_R=self.B_R[layer]
        self.B_R[layer]=sc.parallelize(B_R).join(delta_O_RDD).map(lambda (key,value):(key,value[0]+value[1]*alpha)).collect()
        B=self.B[layer]
        self.B[layer]=sc.parallelize(B).join(sc.parallelize(delta_H)).map(lambda (key,value):(key,value[0]+value[1]*alpha)).collect()

        ##print("after update B:"+str(self.B[layer]))
       ## print("after update BR:"+str(self.B_R[layer]))


        nodeNum = self.node[layer]
        multi_output_H_RDD = output_H_RDD.flatMap(multiply)
        w_U_H_O_RDD=multi_Delta_O_RDD.join(multi_output_H_RDD).map(lambda (key,value):(key,value[0]*value[1]))
        self.W_R[layer]=w_H_T_RDD.join(w_U_H_O_RDD).map(lambda (key,value):(key,value[0]+alpha*value[1])).collect()

        nodeNum= self.node[layer+1]
        w_I_H_RDD=sc.parallelize(input).flatMap(multiply)
        nodeNum=self.node[layer]
        muliti_Delta_H_RDD=sc.parallelize(delta_H).flatMap(multiply).map(lambda (key,value):((key[1],key[0]),value))
        w_U_I_H_RDD=w_I_H_RDD.join(muliti_Delta_H_RDD).map(lambda (key,value):(key,value[0]*value[1]))
        weight=self.W[layer]
        self.W[layer] =sc.parallelize(weight).join(w_U_I_H_RDD).map(lambda (key,value):(key,value[0]+alpha*value[1])).collect()



    def fine_tuning(self,trainSet,iteration,alpha):
        (X,T)=trainSet
        for i in range(iteration):
            for j in range(len(X)):
                (values, delta)=self.ffFordeepNet(X[j],T[j])
                self.bpForDeepNet(values,delta,alpha)


    def ffFordeepNet(self,input,target):
        i=0

        values=list()
        values.append(input)
        def multiply((key, value)):
            result = list()
            for j in range(self.node[i+1]):
                result.append(((key,j),value))

            return result

        def sigmoidoperation((x,y)):
            v=sigmoid(y[0]+y[1])

            return (x,v)

        def calculateDelta((x,y)):
            v=(y[0]-y[1])*y[1]*(1-y[1])

            return (x,v)

        for i in range(len(self.node)-1):

            weightRDD=sc.parallelize(self.W[i])
            biasRDD=sc.parallelize(self.B[i])
            value=sc.parallelize(input).flatMap(multiply).join(weightRDD).map(lambda (key,value):(key,(value[0]*value[1]))).reduceByKey(lambda x,y:x+y).join(biasRDD).map(sigmoidoperation).collect()
            values.append(value)
            input=values[-1]

        output=values[-1]
        delta=sc.parallelize(target).join(sc.parallelize(output)).map(calculateDelta).collect()

        return(values,delta)


    def bpForDeepNet(self,values,delta,alpha):

        deltas=list()
        deltas.append(delta)

        i=0
        def multiply((key,value)):
            result=list(0)
            num=self.node[-2-i]
            for j in range(num):
                result.append(((j,key),value))
            return result


        for i in range(len(self.node)-2):
            weight=self.W[-1-i]
            value=values[-2-i]
            deltaRDD=sc.parallelize(deltas[-1]).flatMap(multiply).join(sc.parallelize(weight)).map(lambda (x,y):(x[0],y[0]*y[1])).reduceByKey(lambda x,y:x+y).join(sc.parallelize(value)).map(lambda x,y:(x,y[0]*y[0]*(1-y[0])))
            deltas.append(deltaRDD.collect())



        for j in range(len(self.node)-1):
            input=values[i]
            delta=deltas[-1-i]
            weight=self.W[i]
            bias=self.B[i]

            self.B[i]=sc.parallelize(bias).join(delta).map(lambda x,y:(x,y[0]+alpha*y[1])).collect()

            i=self.node[j+1]
            weight_updateRDDfrominput=sc.parallelize(input).flatMap(multiply)
            i=self.node[j]
            weight_updateRDDfromdelta=sc.parallelize(delta).flatMap(multiply).map(lambda x,y:((x[1],x[0]),y))
            weight_updateRDD=weight_updateRDDfrominput.join(weight_updateRDDfromdelta).map(lambda x,y:(x,y[0]*y[1]))
            self.W[i]=sc.parallelize(weight).join(weight_updateRDD).map(lambda x,y:(x,y[0]+y[1]*alpha)).collect()



X=list()
e=list()

for i in range(number):
    e.append((i,0.5))
X.append(e)


s=Sautoecoder([number,number,number],0.5,0.5)

start = time.time()
s.pretrain(iteration,X,0.5)
time= time.time()-start
print ("dimension: "+str(number))
print("number of weight: "+str(number*number))
print("spark spend for  "+str(iteration)+" times :"+str(time))

output=open("result","w")
lines=list()
lines.append("dimension: "+str(number)+"\n")
lines.append("number of weight: "+str(number*number)+"\n")
lines.append("spark spend for  "+str(iteration)+" times :"+str(time)+"\n")

output.writelines(lines)
output.close()













