import copy, numpy as np


def sigmoid(x):
    return 1/(1+np.exp(-x))

def sigmoid_otput_to_derivation(output):
    return output*(1-output)


def tanh_derivative(values):
    return 1. - tanh(values) ** 2

def tanh(x):
    return (np.exp(x)-np.exp(-x))/(np.exp(x)+np.exp(-x))





class Lstm:
    ## initial a LSTM object
    def __init__(self,input_dim, hidden_dim,output_dim,randomSize,alpha):
        self.input_dim=input_dim
        self.hidden_dim=hidden_dim
        self.output_dim=output_dim
        self.randomSize=randomSize
        self.alpha=alpha

        self.synapse_x_i = 2*randomSize * np.random.random((input_dim, hidden_dim)) - randomSize
        self.synapse_U_i = 2 *randomSize* np.random.random((hidden_dim, hidden_dim)) - randomSize

        self.synapse_x_f = 2*randomSize * np.random.random((input_dim, hidden_dim)) - randomSize
        self.synapse_U_f = 2 *randomSize* np.random.random((hidden_dim, hidden_dim)) - randomSize

        self.synapse_x_o = 2*randomSize * np.random.random((input_dim, hidden_dim)) - randomSize
        self.synapse_U_o = 2 *randomSize* np.random.random((hidden_dim, hidden_dim)) - randomSize

        self.synapse_x_new = 2 *randomSize* np.random.random((input_dim, hidden_dim)) - randomSize
        self.synapse_U_new = 2 * randomSize*np.random.random((hidden_dim, hidden_dim)) - randomSize

        self.synapse_h_o = 2 *randomSize* np.random.random((hidden_dim, output_dim)) - randomSize

        self.synapse_x_i_update = np.zeros_like(self.synapse_x_i)
        self.synapse_U_i_update = np.zeros_like(self.synapse_U_i)

        self.synapse_x_f_update = np.zeros_like(self.synapse_x_f)
        self.synapse_U_f_update = np.zeros_like(self.synapse_U_f)

        self.synapse_x_o_update = np.zeros_like(self.synapse_x_o)
        self.synapse_U_o_update = np.zeros_like(self.synapse_U_o)

        self.synapse_x_new_update = np.zeros_like(self.synapse_x_new)
        self.synapse_U_new_update = np.zeros_like(self.synapse_U_new)

        self.synapse_h_o_update = np.zeros_like(self.synapse_h_o)


    ## training an example, each eaxmple contains more than 1 splits
    ## return the error and the output
    def train(self,inputList,targetList,inputSize):
        Y = list()

        overallError = 0

        layer_o_deltas = list()
        i_gates = list()
        f_gates = list()
        o_gates = list()
        g_gates = list()  # new memory
        states = list()
        h_outputs = list()

        states.append(np.zeros(self.hidden_dim))
        h_outputs.append(np.zeros(self.hidden_dim))

        for position in range(inputSize):
            X=np.atleast_2d(inputList[position])
            T=targetList[position]

            i_gate = sigmoid(np.dot(X, self.synapse_x_i) + np.dot(h_outputs[-1], self.synapse_U_i))
            o_gate = sigmoid(np.dot(X, self.synapse_x_o) + np.dot(h_outputs[-1], self.synapse_U_o))
            f_gate = sigmoid(np.dot(X, self.synapse_x_f) + np.dot(h_outputs[-1], self.synapse_U_f))
            g_gate = sigmoid(np.dot(X, self.synapse_x_new) + np.dot(h_outputs[-1], self.synapse_U_new))
            state = (i_gate * g_gate + states[-1] * f_gate)
            h_output = tanh(state) * o_gate

            output = sigmoid(np.dot(h_output, self.synapse_h_o))

            layer_o_error = T - output


            layer_o_deltas.append(layer_o_error * sigmoid_otput_to_derivation(output))

            overallError += np.abs(layer_o_error[0][0])




            Y.append(output)

            i_gates.append(copy.deepcopy(i_gate))
            o_gates.append(copy.deepcopy(o_gate))
            f_gates.append(copy.deepcopy(f_gate))
            g_gates.append(copy.deepcopy(g_gate))
            states.append(copy.deepcopy(state))
            h_outputs.append(copy.deepcopy(h_output))

        future_o_delta = np.zeros(self.hidden_dim)
        future_i_delta = np.zeros(self.hidden_dim)
        future_f_delta = np.zeros(self.hidden_dim)
        future_g_delta = np.zeros(self.hidden_dim)
        future_state_delta = np.zeros(self.hidden_dim)
        future_f_gate = np.zeros(self.hidden_dim)

        for position in range(inputSize):
            X = np.atleast_2d(inputList[-1-position])


            i_gate=i_gates[-1-position]
            o_gate=o_gates[-1-position]
            f_gate=f_gates[-1-position]
            g_gate=g_gates[-1-position]





            output_delta=layer_o_deltas[-1-position]

            state = states[-1-position]
            h_output = h_outputs[-1-position]
            h_prev_output=h_outputs[-2-position]
            prev_state=states[-2-position]



            h_delta=(future_o_delta.dot(self.synapse_U_o.T)+\
                     future_i_delta.dot(self.synapse_U_i.T)+\
                     future_f_delta.dot(self.synapse_U_f.T)+\
                     future_g_delta.dot(self.synapse_U_new.T)+ \
                     output_delta.dot(self.synapse_h_o.T))

            o_delta=h_delta*tanh(state)*sigmoid_otput_to_derivation(o_gate)

            state_delta=h_delta*o_gate*tanh_derivative(state)+future_state_delta*future_f_gate

            f_delta=state_delta*prev_state*sigmoid_otput_to_derivation(f_gate)

            i_delta=state_delta*g_gate*sigmoid_otput_to_derivation(i_gate)

            g_delta=state_delta*i_gate*sigmoid_otput_to_derivation(g_gate)




            self.synapse_h_o_update +=np.atleast_2d(h_output).T.dot(output_delta)


            self.synapse_U_i_update +=self.alpha*np.atleast_2d(h_prev_output).T.dot(i_delta)
            self.synapse_U_f_update += self.alpha * np.atleast_2d(h_prev_output).T.dot(f_delta)
            self.synapse_U_o_update += self.alpha * np.atleast_2d(h_prev_output).T.dot(o_delta)
            self.synapse_U_new_update+= self.alpha * np.atleast_2d(h_prev_output).T.dot(g_delta)

            self.synapse_x_i_update +=self.alpha*np.atleast_2d(X).T.dot(i_delta)
            self.synapse_x_f_update += self.alpha * np.atleast_2d(X).T.dot(f_delta)
            self.synapse_x_o_update += self.alpha * np.atleast_2d(X).T.dot(o_delta)
            self.synapse_x_new_update += self.alpha * np.atleast_2d(X).T.dot(g_delta)


            future_o_delta =o_delta
            future_i_delta =i_delta
            future_f_delta =f_delta
            future_g_delta =g_delta
            future_state_delta =state_delta
            future_f_gate =f_gate


        return (overallError,Y)

    ## update the weight
    def upadte(self):

        self.synapse_h_o += self.synapse_h_o_update

        self.synapse_U_i += self.synapse_U_i_update
        self.synapse_U_f += self.synapse_U_f_update
        self.synapse_U_o += self.synapse_U_o_update
        self.synapse_U_new += self.synapse_U_new_update

        self.synapse_x_i += self.synapse_x_i_update
        self.synapse_x_f += self.synapse_x_f_update
        self.synapse_x_o += self.synapse_x_o_update
        self.synapse_x_new += self.synapse_x_new_update

        self.synapse_h_o_update *= 0

        self.synapse_U_i_update *= 0
        self.synapse_U_f_update *= 0
        self.synapse_U_o_update *= 0
        self.synapse_U_new_update *= 0

        self.synapse_x_i_update *= 0
        self.synapse_x_f_update *= 0
        self.synapse_x_o_update *= 0
        self.synapse_x_new_update *= 0

    ## readWeight and writeWeight is not used in the test
    ## this function is the save weights into file
    def readWeight(self,version):
        self.synapse_x_i=np.loadtxt('weight/version'+version+'/synapse_x_i',self.synapse_x_i)
        self.synapse_U_i=np.loadtxt('weight/version' + version + '/synapse_U_i', self.synapse_U_i)

        self.synapse_x_f=np.loadtxt('weight/version' + version + '/synapse_x_f', self.synapse_x_f)
        self.synapse_U_f=np.loadtxt('weight/version' + version + '/synapse_U_f', self.synapse_U_f)

        self.synapse_x_o=np.loadtxt('weight/version' + version + '/synapse_x_o', self.synapse_x_o)
        self.synapse_U_o=np.loadtxt('weight/version' + version + '/synapse_U_o', self.synapse_U_o)

        self.synapse_x_new=np.loadtxt('weight/version' + version + '/synapse_x_new', self.synapse_x_new)
        self.synapse_U_new=np.loadtxt('weight/version' + version + '/synapse_U_new', self.synapse_U_new)

        self.synapse_h_o=np.loadtxt('weight/version' + version + '/synapse_h_o', self.synapse_h_o)

    ##clean the weight, it is used after prediction.
    def clean(self):
        self.synapse_h_o_update *= 0

        self.synapse_U_i_update *= 0
        self.synapse_U_f_update *= 0
        self.synapse_U_o_update *= 0
        self.synapse_U_new_update *= 0

        self.synapse_x_i_update *= 0
        self.synapse_x_f_update *= 0
        self.synapse_x_o_update *= 0
        self.synapse_x_new_update *= 0

    ##set the study rate
    def setAlpha(self,rate):
        self.alpha=rate


    def writeWeight(self,version):
        np.savetxt('weight/version'+version+'/synapse_x_i',self.synapse_x_i)
        np.savetxt('weight/version' + version + '/synapse_U_i', self.synapse_U_i)

        np.savetxt('weight/version' + version + '/synapse_x_f', self.synapse_x_f)
        np.savetxt('weight/version' + version + '/synapse_U_f', self.synapse_U_f)

        np.savetxt('weight/version' + version + '/synapse_x_o', self.synapse_x_o)
        np.savetxt('weight/version' + version + '/synapse_U_o', self.synapse_U_o)

        np.savetxt('weight/version' + version + '/synapse_x_new', self.synapse_x_new)
        np.savetxt('weight/version' + version + '/synapse_U_new', self.synapse_U_new)

        np.savetxt('weight/version' + version + '/synapse_h_o', self.synapse_h_o)



'''
        synapse_x_i =
        synapse_U_i =

        synapse_x_f =
        synapse_U_f =

        synapse_x_o =
        synapse_U_o =

        synapse_x_new =
        synapse_U_new =

        synapse_h_o =

'''





