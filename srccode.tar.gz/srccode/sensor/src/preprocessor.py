import copy, numpy as np
import re
import scipy.stats as stats
import random
import os

path="/home/alex/pythonProject/sensor"

## generate the 4 points of each whole action. point of start of the whole action,
#  point of start of movement, point of end of movement, point of end of this whole action
def genrateAction():
    actionTable=list()
    for line in open(path+'/readme/table'):
        actions=line.split('\t')
        actionTable.append(actions)


    example=list()
    for line in open(path+'/readme/seglocation (copy).csv'):
        listtttt=line.split("\t")
        for i in range((len(listtttt)-1)/2):
            fileIndex = int(listtttt[0].replace('.dat','').replace('S',''))
            actiontype=(actionTable[fileIndex-1][i])
            if i==0:
                start=int(listtttt[1])-300
                end0=int(listtttt[2])
                end=int(listtttt[3])
                example.append((fileIndex,actiontype,start,start+300,end0,end))
            elif i==(len(listtttt)-1)/2-1:
                start=int(listtttt[-3])
                start1=int(listtttt[-2])
                end0=int(listtttt[-1])
                end=int(listtttt[-1])+100
                example.append((fileIndex,actiontype,start, start1, end0, end))
            else:
                start=int(listtttt[i*2])
                start1=int(listtttt[i*2+1])
                end0=int(listtttt[i*2+2])
                end=int(listtttt[i*2+3])
                example.append((fileIndex,actiontype,start, start1, end0, end))

    return example


## generate all the examples
def generateTraningExample(example):
    for ex in example:
        generateExample(ex)


## generate each of examples
def generateExample(ex):

    (fileindex,actiontype,enterpoint,start,end,endpoint)=ex
    lines=list()
    filepath=""
    if fileindex<10:
        filepath=(path+'/rawData/S0'+ \
                             str(fileindex)+'.dat')
    else:
        filepath=(path+'/rawData/S'+ \
                             str(fileindex)+'.dat')
    indexOfline=-1
    linesofRawData = list()
    for line in open(filepath):
        if enterpoint<=indexOfline<=endpoint:
            linesofRawData.append(line)
        indexOfline+=1

    for i in range(len(linesofRawData)):
        words=linesofRawData[i].split('\t')

        words.remove(words[0])
        line=''
        for word in words:

            line+=(word+'\t')
        line=line.replace('\n','')
        linesofRawData[i]=line


    points=list()
    (x,t)=generateSegment(ex,40,20)


    for indexOfRawData in range(len(x)):
        rawDataForonesegment=list()
        (s,e)=x[indexOfRawData]
        target=t[indexOfRawData]
        length=e-s


        for i in range(length):

            rawDataForonesegment.append(linesofRawData[s-enterpoint+i])


        points.append(getFeatures(rawDataForonesegment,target))
    input=open(path+'/trainExample/'+ \
               str(fileindex)+'s'+str(start)+'e'+str(end)+'.dat','w')
    input.writelines(points)







##split a whole action into smaller split, length is the length of the window, step is the length of the step
def generateSegment(ex,length,step):
    (fileindex,actiontype,enterpoint,start,end,endpoint)=ex
    x=list()
    t=list()

    index=0
    for i in range((endpoint-enterpoint-length)/step+1):
        if(index==(endpoint-enterpoint-length)/step):
            s=enterpoint+i * step
            e=endpoint
            x.append((s,e))
        else:
            s=enterpoint+i * step
            e=s+length
            x.append((s,e))
        index+=1

    for (s,e) in x:
        type=-888
        median=float(s+e)/2

        if enterpoint<median<=start:
            type=0
        elif start<median<=end:
            type=actiontype

        elif end<median<=endpoint:

            type=0
        t.append(type)

    return (x,t)



ex=(11, '1', 382, 682, 1000, 1052)
(x,t)=generateSegment(ex,40,20)



'''
correct=1
silence=0
wrong =-1

half=-1
left=-10
right=-11

'''

## get the statistic description of this split
def getFeatures(rawDataForonesegment,target):
    line0=list()
    line1=list()
    line2=list()
    line3=list()
    line4=list()
    line5=list()
    for i in range(len(rawDataForonesegment)):
        line=rawDataForonesegment[i].strip().split('\t')
        assert len(line)==6
        for j in range(len(line)):
           line[j]=float(line[j].strip())
           if j==0:
               line0.append(line[j])
           elif j==1:
               line1.append(line[j])
           elif j== 2:
               line2.append(line[j])
           elif j == 3:
               line3.append(line[j])
           elif j == 4:
               line4.append(line[j])
           elif j == 5:
               line5.append(line[j])

    dataset0=np.array(line0)
    dataset1=np.array(line1)
    dataset2=np.array(line2)
    dataset3=np.array(line3)
    dataset4=np.array(line4)
    dataset5=np.array(line5)

    feature0= [np.mean(dataset0), dataset0.std(), stats.percentileofscore(dataset0, 50) \
        , stats.percentileofscore(dataset0, 25), stats.percentileofscore(dataset0, 75), \
                np.max(dataset0) - np.min(dataset0), \
                stats.kurtosis(dataset0), stats.skew(dataset0), np.max(dataset0), np.min(dataset0), dataset0.var()]
    feature1= [np.mean(dataset1), dataset1.std(), stats.percentileofscore(dataset1, 50) \
        , stats.percentileofscore(dataset1, 25), stats.percentileofscore(dataset1, 75), \
                np.max(dataset1) - np.min(dataset1), \
                stats.kurtosis(dataset1), stats.skew(dataset1), np.max(dataset1), np.min(dataset1), dataset1.var()]
    feature2= [np.mean(dataset2), dataset2.std(), stats.percentileofscore(dataset2, 50) \
        , stats.percentileofscore(dataset2, 25), stats.percentileofscore(dataset2, 75), \
                np.max(dataset2) - np.min(dataset2), \
                stats.kurtosis(dataset2), stats.skew(dataset2), np.max(dataset2), np.min(dataset2), dataset2.var()]
    feature3= [np.mean(dataset3), dataset3.std(), stats.percentileofscore(dataset3, 50) \
        , stats.percentileofscore(dataset3, 25), stats.percentileofscore(dataset3, 75), \
                np.max(dataset3) - np.min(dataset3), \
                stats.kurtosis(dataset3), stats.skew(dataset3), np.max(dataset3), np.min(dataset3), dataset3.var()]
    feature4= [np.mean(dataset4), dataset4.std(), stats.percentileofscore(dataset4, 50) \
        , stats.percentileofscore(dataset4, 25), stats.percentileofscore(dataset4, 75), \
                np.max(dataset4) - np.min(dataset4), \
                stats.kurtosis(dataset4), stats.skew(dataset4), np.max(dataset4), np.min(dataset4), dataset4.var()]
    feature5= [np.mean(dataset5), dataset5.std(), stats.percentileofscore(dataset5, 50) \
        , stats.percentileofscore(dataset5, 25), stats.percentileofscore(dataset5, 75), \
                np.max(dataset5) - np.min(dataset5), \
                stats.kurtosis(dataset5), stats.skew(dataset5), np.max(dataset5), np.min(dataset5), dataset5.var()]

    stringOfFeatures=''
    for word in feature0:
        stringOfFeatures+=(str(word)+'\t')
    for word in feature1:
        stringOfFeatures+=(str(word)+'\t')
    for word in feature2:
        stringOfFeatures+=(str(word)+'\t')
    for word in feature3:
        stringOfFeatures+=(str(word)+'\t')
    for word in feature4:
        stringOfFeatures+=(str(word)+'\t')
    for word in feature5:
        stringOfFeatures+=(str(word)+'\t')

    stringOfFeatures+=(str(target)+'\n')
    return stringOfFeatures

## this function is to normalization example in trainExample.
def normalization(num):
    min=np.zeros(num)
    max=np.zeros(num)

    for i in range(len(min)):
        min[i]=float('inf')
        max[i]=float('-inf')

    oldpath=path+'/trainExample'
    newpath = path+'/normalizedExample'
    for filename in os.listdir(path+'/trainExample'):

        for line in open(oldpath+'/'+filename):
            stringRecord=line.split('\t')
            record=[float(word) for word in stringRecord]
            for i in range(num):
                if record[i]<min[i]:
                    min[i]=record[i]
                if record[i]>max[i]:
                    max[i]=record[i]


    mid = (min + max) / 2
    scale = (max - min) / 2

    for filename in os.listdir(path+'/trainExample'):
        lines=list()
        for line in open(oldpath+'/'+filename):
            stringRecord=line.split('\t')
            assert len(stringRecord)==num+1
            record=[float(word) for word in stringRecord]
            stringOfLine=''
            for i in range(num):
                if scale[i]==0:
                    record[i]=0
                else:
                    record[i]=(record[i] - mid[i]) / scale[i]
                stringOfLine+=(str(record[i])+'\t')
            stringOfLine+=(str(record[-1])+'\n')
            lines.append(stringOfLine)

        input=open(newpath+'/'+filename,'w')
        input.writelines(lines)
        input.close()





example=genrateAction()
generateTraningExample(example)
normalization(66)


