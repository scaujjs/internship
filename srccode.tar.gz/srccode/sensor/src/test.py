import random
import Lstm
import os
import math

path="/home/alex/pythonProject/sensor"




trainSet=list()
testSet=list()
unionSet=list()

## this block is aim to read and convert the normalized example to examples and targets
for filename in os.listdir(path+'/normalizedExample'):
    X=list()
    T=list()
    lineIndex=0
    for line in open(path+'/normalizedExample' + '/' + filename):
        lineIndex+=1
        stringRecord = line.split('\t')
        record = [float(word) for word in stringRecord]

        target=record[-1]

        if target==0:
            T.append([1,0,0])
        elif target ==-1 or target ==-11 or target ==-10:
            T.append([0,0,1])
        elif target == 1:
            T.append([0, 1, 0])
        else:
            assert True

        record.remove(record[-1])


        itemindex=0
        for item in record:
            itemindex+=1
            if math.isnan(item):
                print record
                print len(record)
                print filename
                print lineIndex
                print itemindex
                print item

        X.append(record)

    p=random.random()
    unionSet.append((X,T))
    if p<0.5:
        trainSet.append((X,T))
    else:
        testSet.append((X,T))


def splitinto5part(unionSet):
    part0=list()
    part1=list()
    part2=list()
    part3=list()
    part4=list()

    for (X,T) in unionSet:
        p=random.random()
        if 0.2>p>=0:
            part0.append((X,T))
        elif 0.4>p>=0.2:
            part1.append((X,T))
        elif 0.6>p>=0.4:
            part2.append((X,T))
        elif 0.8>p>=0.6:
            part3.append((X,T))
        else:
            part4.append((X,T))

    parts=list()
    parts.append(part0)
    parts.append(part1)
    parts.append(part2)
    parts.append(part3)
    parts.append(part4)

    return parts


parts=splitinto5part(unionSet)


overall=0
overallcorrect=0


##cross validation
for outer in range(5):

    total=0
    correct=0
    count=0
    HMM2 = Lstm.Lstm(66, 30, 3, 0.2, 0.3)

    for (X,T,) in parts[outer]:
        (overallError, output) = HMM2.train(X, T, len(T))

        pred = list()

        for re in output:
            for i in range(3):
                if re[0][i] < 0.3:
                    re[0][i] = 0
                elif re[0][i] > 0.7:
                    re[0][i] = 1


        temp=0
        for i in range(len(T)):

            if(output[i][0][0]==T[i][0] and output[i][0][1]==T[i][1] and output[i][0][2]==T[i][2]):
                temp+=1


        total=total+len(T)
        correct=correct+temp
        count=count+1
        HMM2.clean()

    print "cross validation(part"+str(outer)+"): "
    print " before training "
    print " total test : "+str(total)
    print " correct anwser: "+str(correct)





##
    iteration=20
    for epoch in range(iteration):
        for inner in range(5):
            if inner==output:
                continue
            overallErrorFrom1loop=0.0
            for (X,T) in parts[inner]:
                true=list()



                (overallError, output) = HMM2.train(X, T, len(T))
                HMM2.upadte()

              ##  result=round(d[0][0])
                overallErrorFrom1loop+=overallError

        ##        print epoch
        ##        print "overall " + str(overallErrorFrom1loop/(len(T)) )
                for re in output:
                    for i in range(3):
                        if re[0][i] < 0.3:
                            re[0][i] = 0
                        elif re[0][i] > 0.7:
                            re[0][i] = 1

                result = ''
                for re in output:
                    if re[0][0] == 1:
                        result += 's '
                    elif re[0][1] == 1:
                        result += 'r '
                    elif re[0][2] == 1:
                        result += 'w '
                    else:
                        result+='x '
                result += str(len(output))

        ##        print result


    total=0
    correct=0
    count=0



    for (X,T,) in parts[outer]:
        (overallError, output) = HMM2.train(X, T, len(T))

        pred = list()

        for re in output:
            for i in range(3):
                if re[0][i] < 0.3:
                    re[0][i] = 0
                elif re[0][i] > 0.7:
                    re[0][i] = 1


        result=''
        for re in output:
            if re[0][0]==1:
                result+='s '
            elif re[0][1]==1:
                result+='r '
            elif re[0][2]==1:
                result+='w '
        result+=str(len(output))

##        print result

        temp=0
        for i in range(len(T)):
            if (output[i][0][0] == T[i][0] and output[i][0][1] == T[i][1] and output[i][0][2] == T[i][2]):
                temp+=1


        total=total+len(T)
        correct=correct+temp
        count=count+1
        HMM2.clean()
    overall+=total;
    overallcorrect+=correct;
    print
    print " after training "
    print " total test : "+str(total)
    print " correct anwser: "+str(correct)
    print ""

print"-------------------"
print"-------------------"


print "overall test number: "+str(overall)
print "overall correct: "+str(overallcorrect)
print "classification accuracy: "+str(overallcorrect/float(overall))